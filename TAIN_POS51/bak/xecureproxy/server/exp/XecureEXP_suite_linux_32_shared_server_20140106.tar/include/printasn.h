/*****************************************************************************/
/* Copyright (C) 1999-2007 OSS Nokalva, Inc.  All rights reserved.           */
/*****************************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/*****************************************************************************/
/* FILE: @(#)printasn.h	14.2  04/10/11                       */
/*****************************************************************************/
/* This header file is preserved for backward compatibility and should not   */
/* be used by new applications. Use osspasn.h in all cases instead.          */
/*****************************************************************************/

#include "osspasn.h"
