/*****************************************************************************/
/* Copyright (C) 2002-2007 OSS Nokalva, Inc.  All rights reserved.           */
/*****************************************************************************/

/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED. */

/*****************************************************************************/
/* FILE: @(#)asn1glob.h	14.2  05/04/30                       */
/*****************************************************************************/
/* This header file is preserved for backward compatibility and should not   */
/* be used by new applications. Use osscag.h in all cases instead.           */
/*****************************************************************************/

#include "osscag.h"
